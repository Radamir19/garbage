package org.example.subscription_service.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;

import java.time.OffsetDateTime;
import java.util.UUID;

@Entity
@Table(name = "outbox")
@NoArgsConstructor
@Getter
@Setter
public class OutboxEntity {

    @Id
    private UUID id;

    @Column(nullable = false)
    private String aggregate;

    @Column(nullable = false)
    private String payload;

    @Column(nullable = false)
    @CreationTimestamp
    private OffsetDateTime createdAt;

    @Column(nullable = false)
    private String status;

    @Column(nullable = false)
    private String type;

    private OffsetDateTime publishedAt;

    private Short attempts = 0;
}
