package org.example.flowmanager.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;

import java.time.OffsetDateTime;
import java.util.UUID;

@Entity
@Table(name = "outbox")
@Getter
@Setter
@NoArgsConstructor
public class OutboxEntity {
    @Id
    private UUID fileId;

    @Column(nullable = false)
    private String aggregate;

    @Column(nullable = false)
    private String payload;

    @CreationTimestamp
    private OffsetDateTime createdAt;

    private OffsetDateTime publishedAt;

    @Column(nullable = false)
    private String status;

    @Column(nullable = false)
    private Short attempts = 0;
}
